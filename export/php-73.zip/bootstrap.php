#!/opt/bin/php
<?php

$appRoot = getenv('LAMBDA_TASK_ROOT');

require $appRoot.'/runtime.php';
